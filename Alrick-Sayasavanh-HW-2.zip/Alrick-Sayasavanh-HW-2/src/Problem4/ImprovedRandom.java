package Problem4;
import java.util.Random;

@SuppressWarnings("serial")
public class ImprovedRandom extends Random{
	private int betweenvalue = 0;
	
	public ImprovedRandom(long seed){
		super(seed);
	}
	
	public ImprovedRandom() {
		super();
	}
	public int randomBetween(int lowest, int highest){
		betweenvalue = super.nextInt(highest+1);
		if (betweenvalue < lowest){
			return betweenvalue + lowest;
		}
		return betweenvalue;
	}

}
