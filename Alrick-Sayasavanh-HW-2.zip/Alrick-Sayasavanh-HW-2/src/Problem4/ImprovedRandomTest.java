package Problem4;

import static org.junit.Assert.*;

import org.junit.Test;

public class ImprovedRandomTest {

	@Test
	public void testRandomBetween() {
		ImprovedRandom ir = new ImprovedRandom();
		
		int a = ir.randomBetween(2, 5);
		
		assertTrue(a >= 2 && a <= 5);
	}

}
