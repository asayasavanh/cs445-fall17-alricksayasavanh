package Problem2;

public class B {
	
	public B(){
		
	}
	
	public void call(){
		
	}

}
