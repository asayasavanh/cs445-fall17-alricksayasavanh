package Problem2;

public class F {
	private D[] dArray;
	public F(){
		this.dArray = new D[2];
	}
}
