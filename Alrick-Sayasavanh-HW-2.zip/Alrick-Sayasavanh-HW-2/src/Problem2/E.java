package Problem2;

public class E extends C{

	public E(){
		
	}
}
