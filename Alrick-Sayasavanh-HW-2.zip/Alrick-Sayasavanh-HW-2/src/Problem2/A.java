package Problem2;

public class A {

	public A() {
		
	}
	
	public void method(B b){
		b.call();
	}
}
