package Problem2;

public class D {
	private F[] fArray;
	
	public D(){
		this.fArray = new F[5];
	}
	
	public void call(){
		
	}

}
