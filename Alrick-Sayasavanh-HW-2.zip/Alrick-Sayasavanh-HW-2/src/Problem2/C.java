package Problem2;

public class C extends A{
	
	public C(){
		
	}

	public void method(D d){
		d.call();
	}
}
