package Problem5;


public class ImprovedStringTokenizer {
	private String t;
	private String[] textArray;
	private int count;
	
	public ImprovedStringTokenizer(String text){
		this.t = text;
		count = 0;
		textArray = t.split(" ");
	}
	
	public boolean hasMoreTokens(){
		return (count < textArray.length-1);
		}
	
	public String nextToken(){
		if (count >= textArray.length){
			return null;
		}
		else {
			count++;
			return textArray[count-1];
		}
	}
	
	public int countTokens(){
		return (textArray.length - count);
	}
	
	public String[] getArr(){
		return textArray;
	}

}
