package Problem5;

import static org.junit.Assert.*;

import org.junit.Test;

public class ImprovedStringTokenizerTest {

	@Test
	public void testGetArr() {
		String testString = "This is a test string";
		String[] testStringArray = {"This", "is", "a", "test", "string"};
		
		ImprovedStringTokenizer ist = new ImprovedStringTokenizer(testString);
		
		assertArrayEquals(testStringArray, ist.getArr());
	}
	
	@Test
	public void testHasMoreTokens(){
		String testString = "This is a test string";
		ImprovedStringTokenizer ist = new ImprovedStringTokenizer(testString);
		int count = 0;
		while (count < 4){
			assertTrue(ist.hasMoreTokens());
			ist.nextToken();
			count++;
		}
		assertFalse(ist.hasMoreTokens());
		
	}
	
	@Test
	public void testNextToken(){
		String testString = "This is a test string";
		ImprovedStringTokenizer ist = new ImprovedStringTokenizer(testString);
		assertEquals(ist.nextToken(), "This");
		assertEquals(ist.nextToken(), "is");
		assertEquals(ist.nextToken(), "a");
		assertEquals(ist.nextToken(), "test");
		assertEquals(ist.nextToken(), "string");
		
	}
	
	@Test
	public void testCountTokens(){
		String testString = "This is a test string";
		ImprovedStringTokenizer ist = new ImprovedStringTokenizer(testString);
		assertEquals(5, ist.countTokens());
		ist.nextToken();
		assertEquals(4, ist.countTokens());
		ist.nextToken();
		assertEquals(3, ist.countTokens());
		ist.nextToken();
		assertEquals(2, ist.countTokens());
		ist.nextToken();
		assertEquals(1, ist.countTokens());
		ist.nextToken();
		assertEquals(0, ist.countTokens());
		
		
	}

}
