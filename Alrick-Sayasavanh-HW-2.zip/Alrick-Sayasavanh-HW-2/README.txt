For this assignment, there is no building required. There are simple classes that were created,
but can be tested using junit. To use junit testing, type the following in the terminal:
$ junit

Then type in the class that is in need of testing.

NOTE: Due to this, there is no proper script to execute these classes.

