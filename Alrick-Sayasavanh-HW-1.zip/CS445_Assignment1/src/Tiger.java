
public class Tiger extends Creature{
	
	private String moveText;
	
	public Tiger(String name){
		super(name);
		moveText = (super.toString() + " has just pounced.");
	}
	
	public String getMoveText(){
		return moveText;
	}
	
	public void move(){
		System.out.println(moveText);
	}

}
