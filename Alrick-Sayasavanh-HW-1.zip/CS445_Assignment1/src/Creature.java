
public abstract class Creature extends Thing{
	
	private Thing lastate = new Thing("");
	
	public Creature(String name){	
		super(name);
	}
	
	public void eat(Thing aThing){
		switch (this.getClass().getSimpleName()){
			default:
				System.out.println(this.toString() + " has just eaten " + aThing);
				lastate = new Thing(aThing.toString());
				break;
		
		}
		//System.out.println(this.toString() + " has just eaten a " + aThing);
	}
	
	public String lastAte(){
		return lastate.toString();
	}
	
	public abstract void move();
	
	public void whatDidYouEat(){
		if (lastate.toString().equals("")){
			System.out.println(this.toString() + " has nothing to eat!");
		}
		else {
			System.out.println(this.toString() + " has eaten a(n) " + lastate.toString() + ".");
		}
	}

}
