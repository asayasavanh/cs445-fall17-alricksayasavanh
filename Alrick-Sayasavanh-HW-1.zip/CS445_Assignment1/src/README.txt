To run the program, type "make" in the terminal and where the files are present.
Hit Enter.

Then, type "java TestCreature"
Hit Enter.
