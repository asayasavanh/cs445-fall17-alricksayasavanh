
public class Ant extends Creature{
	
	private String moveText;
	public Ant(String name){
		super(name);
		moveText = (super.toString() + " is crawling around.");
	}
	
	
	public String getMoveText(){
		return moveText;
	}
	
	public void move(){
		System.out.println(moveText);
	}

}
