
public class Fly extends Creature{
	
	private String moveText;
	
	public Fly(String name){
		super(name);
		moveText = (super.toString() +  " is buzzing around in flight.");
	}

	public void eat(Thing aThing){
		if (aThing.getClass().getSimpleName().equals("Thing")){
			super.eat(aThing);
		}
		else if (aThing.getClass().getSuperclass().getSimpleName().equals("Creature")){
			System.out.println(super.toString() + " won't eat a(n) " + aThing.getClass().getSimpleName());
		}
		else {
			System.out.println("Nothing happens");
		}
	}
	
	public String getMoveText(){
		return moveText;
	}
	
	public void move(){
		fly();
	}
	
	public void fly(){
		System.out.println(moveText);
	}
}
