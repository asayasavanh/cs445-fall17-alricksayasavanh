//import java.util.Scanner;

public class TestCreature {
//	public int add(int a, int b) {
//		return a+b;
//	}
//	
//	public String ConCat (String a, String b)
//	{
//		return a+b;
//	}
	public static final int CREATURE_COUNT = 4;
	public static final int THING_COUNT = 6;
	
	public static void main(String[]args){
		Thing[] things = new Thing[THING_COUNT];
		things[0] = new Thing("Banana");
		things[1] = new Ant("Aaron");
		things[2] = new Bat("Becky");
		things[3] = new Fly("Felicia");
		things[4] = new Tiger("Tony");
		things[5] = new Tiger("Tommy");
		
		Creature[] creatures = new Creature[CREATURE_COUNT];
		creatures[0] = new Ant("Aaron");
		creatures[1] = new Bat("Becky");
		creatures[2] = new Fly("Felicia");
		creatures[3] = new Tiger("Tony");
		
		System.out.println("Things:");
		System.out.println();
		
		for (int i = 0; i < things.length; i ++ ){
			System.out.println(things[i]);
		}
		
		System.out.println();
		System.out.println("Creatures:");
		System.out.println();
		
		for (int i = 0; i < creatures.length; i++){
			System.out.println(creatures[i].toString());
		}
		
		System.out.println();
		for (int i = 0; i < creatures.length; i++){
			creatures[i].move();
		}
		
		//This is the set of testcases you can check. jUnit test does the same thing.
		System.out.println();
		for (int i = 0; i < creatures.length; i++) {
			for (int j = 0; j < things.length; j++){
				creatures[i].eat(things[j]);
				creatures[i].whatDidYouEat();
			}
		}
		
//		creatures[1].eat(things[0]);
//		creatures[1].whatDidYouEat();
//		creatures[1].eat(creatures[0]);
//		creatures[1].whatDidYouEat();
//		
//		creatures[2].eat(things[0]);
//		creatures[2].whatDidYouEat();
//		creatures[2].eat(creatures[0]);
//		creatures[2].whatDidYouEat();
	}

}
