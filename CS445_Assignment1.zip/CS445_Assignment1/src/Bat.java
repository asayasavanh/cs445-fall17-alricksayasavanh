
public class Bat extends Creature{
	
	public Bat(String name){
		super(name);
	}
	
	@Override
	public void eat(Thing aThing){
//		System.out.println();
//		System.out.println("Eating " + aThing.getClass().toString());
//		System.out.println("Simple Name : " + aThing.getClass().getSimpleName());
//		System.out.println("Type Object : " + aThing.getClass().getSuperclass().getSimpleName());
		
		if (aThing.getClass().getSuperclass().getSimpleName().equals("Creature")){
			super.eat(aThing);
		}
		else if (aThing.getClass().getSimpleName().equals("Thing")){
			System.out.println(super.toString() + " won't eat a(n) " + aThing);
		}
		else {
			System.out.println("Nothing happens");
		}
	}
	
	public void move(){
		fly();
	}

	public void fly(){
		System.out.println(super.toString() + " is swooping through the dark.");
	}
}
