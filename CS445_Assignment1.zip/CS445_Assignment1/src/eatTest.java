//This test assures that each creature is able to eat certain "Things". the "eat" method is used to
//test and see if a "Creature" can eat a specific "Thing". Then, the "assertEquals" function is
//there to determine the last thing that "Creature" ate, checking to see if it was allowed.

import static org.junit.Assert.*;
import org.junit.Test;

public class eatTest {

	@Test
	public void EatTest() {
		
		Ant ant = new Ant("Ant");
		Thing banana = new Thing("Banana");
		Bat bat = new Bat("Bat");
		Fly fly = new Fly("Fly");
		
		ant.eat(banana);
		assertEquals("Banana", ant.lastAte());
		ant.whatDidYouEat();
		ant.eat(bat);
		assertEquals("Bat, the Bat", ant.lastAte());
		ant.whatDidYouEat();
		ant.eat(fly);
		assertEquals("Fly, the Fly", ant.lastAte());
		ant.whatDidYouEat();
		System.out.println();
		
		bat.eat(banana);
		assertEquals("", bat.lastAte());
		bat.whatDidYouEat();
		bat.eat(ant);
		assertEquals("Ant, the Ant", bat.lastAte());
		bat.whatDidYouEat();
		bat.eat(fly);
		assertEquals("Fly, the Fly", bat.lastAte());
		bat.whatDidYouEat();
		System.out.println();
		
		fly.eat(banana);
		assertEquals("Banana", fly.lastAte());
		fly.whatDidYouEat();
		fly.eat(ant);
		assertEquals("Banana", fly.lastAte());
		fly.whatDidYouEat();
		fly.eat(bat);
		assertEquals("Banana", fly.lastAte());
		fly.whatDidYouEat();
		
		
	}

}
