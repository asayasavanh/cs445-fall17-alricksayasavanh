
public class Fly extends Creature{
	
	public Fly(String name){
		super(name);
	}

	public void eat(Thing aThing){
		if (aThing.getClass().getSimpleName().equals("Thing")){
			super.eat(aThing);
		}
		else if (aThing.getClass().getSuperclass().getSimpleName().equals("Creature")){
			System.out.println(super.toString() + " won't eat a(n) " + aThing.getClass().getSimpleName());
		}
		else {
			System.out.println("Nothing happens");
		}
	}
	
	public void move(){
		fly();
	}
	
	public void fly(){
		System.out.println(super.toString() +  " is buzzing around in flight.");
	}
}
