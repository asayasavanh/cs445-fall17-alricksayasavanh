import static org.junit.Assert.*;

import org.junit.Test;

public class moveTest {

	@Test
	public void MoveTest() {
		Ant ant = new Ant("Ant");
		Bat bat = new Bat("Bat");
		Fly fly = new Fly("Fly");
		Tiger tiger = new Tiger("Tiger");
		
		System.out.println(ant.getMoveText());
		assertEquals("Ant, the Ant is crawling around.", ant.getMoveText());
		System.out.println(bat.getMoveText());
		assertEquals("Bat, the Bat is swooping through the dark.", bat.getMoveText());
		System.out.println(fly.getMoveText());
		assertEquals("Fly, the Fly is buzzing around in flight.", fly.getMoveText());
		System.out.println(tiger.getMoveText());
		assertEquals("Tiger, the Tiger has just pounced.", tiger.getMoveText());
	}

}
