To run the program, type "make" in the terminal while being the folder "Alrick-Sayasavanh-HW-3/src/" and hit "enter".

Then, type "java main/TableLamp"
Hit Enter.
