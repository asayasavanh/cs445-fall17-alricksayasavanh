package lightbulb;

import static org.junit.Assert.*;

import org.junit.Test;

public class LightbulbTest {

	@Test
	public void testGetStatus() {
		Lightbulb lb = new Lightbulb();
		assertFalse(lb.getStatus());
		lb.switchStatus();
		assertTrue(lb.getStatus());
	}
	
	@Test
	public void testSwitchStatus(){
		Lightbulb lb = new Lightbulb();
		assertEquals("Lightbulb on", lb.getOnString());
		assertEquals("Lightbulb off", lb.getOffString());
	}

}
