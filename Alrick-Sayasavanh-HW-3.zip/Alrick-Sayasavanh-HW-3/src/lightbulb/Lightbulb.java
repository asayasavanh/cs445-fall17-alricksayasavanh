package lightbulb;

public class Lightbulb implements main.switcher{

	private boolean status;
	private String onString = "Lightbulb on";
	private String offString = "Lightbulb off";
	
	public Lightbulb(){
		this.status = false;
	}
	
	public boolean getStatus(){
		return status;
	}

	public void switchStatus(boolean status){
		if (status){
			on();
		}
		else{
			off();
		}
		
	}
	
	public void on(){
		System.out.println(getOnString());
	}
	public void off(){
		System.out.println(getOffString());
	}
	
	public String getOnString(){
		return onString;
	}
	public String getOffString(){
		return offString;
	}

	@Override
	public void switchStatus() {
		if (status){
			status = false;
		}
		else {
			status = true;
		}
		
	}

}
