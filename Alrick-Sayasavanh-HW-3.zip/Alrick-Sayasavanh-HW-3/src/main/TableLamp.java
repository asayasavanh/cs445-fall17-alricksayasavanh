package main;
import lightbulb.Lightbulb;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class TableLamp {
	
	public static void main(String[]args){
		Lightbulb lightbulb = new Lightbulb();
		PushdownButton button = new PushdownButton();
		JFrame frame = new JFrame("Button");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(200,100);
		
		JPanel panel = new JPanel();
		frame.add(panel);
		
//		Button switchB = new Button("Switch Light");
		
		JButton switchB = new JButton("Switch Light");
//		JButton offB = new JButton("Off");
		
//		
		
		switchB.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent evt){
			button.switchStatus();
			lightbulb.switchStatus(button.getStatus());

		}
	});
		
//		onB.addActionListener(new ActionListener(){
//			public void actionPerformed(ActionEvent evt){
//				if (lightbulb.getStatus()){
//					System.out.println("Button switched to OFF");
//					lightbulb.switchOff();
//				}
//				else {
//					System.out.println("Button switched to ON");
//					lightbulb.switchOn();
//				}
//			}
//		});
		
//		onB.addActionListener(new ActionListener(){
//			public void actionPerformed(ActionEvent evt){
//				System.out.println("Button switched to ON");
//				lightbulb.switchOn();
//			}
//		});
//		
//		offB.addActionListener(new ActionListener(){
//			public void actionPerformed(ActionEvent evt){
//				System.out.println("Button switched to OFF");
//				lightbulb.switchOff();
//			}
//		});
		
		panel.add(switchB);
		frame.setVisible(true);
	}

}
