package main;

import static org.junit.Assert.*;

import org.junit.Test;

public class PushdownButtonTest {

	@Test
	public void testGetStatus() {
		PushdownButton button = new PushdownButton();
		assertFalse(button.getStatus());
		button.switchStatus();
		assertTrue(button.getStatus());
	}
	
	@Test
	public void testSwitchStatus(){
		PushdownButton button = new PushdownButton();
		assertEquals("Button switched to ON", button.getOnString());
		assertEquals("Button switched to OFF", button.getOffString());
	}

}
