package main;

import static org.junit.Assert.*;

import org.junit.Test;

public class ButtonTest {

	@Test
	public void testGetStatus() {
		Button button = new Button();
		assertFalse(button.getStatus());
		button.switchStatus();
		assertTrue(button.getStatus());
	}
	
	@Test
	public void testSwitchStatus(){
		Button button = new Button();
		assertEquals("Button switched to ON", button.getOnString());
		assertEquals("Button switched to OFF", button.getOffString());
	}

}
