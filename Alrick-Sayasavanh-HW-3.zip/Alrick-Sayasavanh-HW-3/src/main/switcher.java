package main;

public interface switcher {
	public void switchStatus();
}
