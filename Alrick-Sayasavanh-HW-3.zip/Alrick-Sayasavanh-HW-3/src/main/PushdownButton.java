package main;
//import javax.swing.JButton;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;

public class PushdownButton implements switcher{

	private boolean sstatus = false;
	private String onString = "Button switched to ON";
	private String offString = "Button switched to OFF";
	public PushdownButton(){

	}
	
	public void switchOff(){
		sstatus = false;
		System.out.println(offString);
	}
	public void switchOn(){
		sstatus = true;
		System.out.println(onString);
	}
	
	public void PushButton(){
		switchStatus();
	}
	
	public void switchStatus(){
		if (sstatus){
			switchOff();
		}
		else{
			switchOn();
		}
	}
	
	public boolean getStatus(){
		return sstatus;
	}
	
	public String getOnString(){
		return onString;
	}
	
	public String getOffString(){
		return offString;
	}
}
